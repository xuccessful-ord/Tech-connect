from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
import sqlite3, hashlib, re

app = Flask(__name__)
app.secret_key = "change-this-secret-in-production"
DB = "vibelink.db"

def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    c = db()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS users(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL, email TEXT UNIQUE NOT NULL, password TEXT NOT NULL,
      account_type TEXT NOT NULL, bio TEXT DEFAULT '', github TEXT DEFAULT '',
      portfolio TEXT DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS jobs(
      id INTEGER PRIMARY KEY AUTOINCREMENT, client_id INTEGER NOT NULL,
      title TEXT NOT NULL, category TEXT NOT NULL, description TEXT NOT NULL,
      budget TEXT DEFAULT '', status TEXT DEFAULT 'Open'
    );
    CREATE TABLE IF NOT EXISTS applications(
      id INTEGER PRIMARY KEY AUTOINCREMENT, job_id INTEGER NOT NULL,
      professional_id INTEGER NOT NULL, message TEXT DEFAULT '',
      status TEXT DEFAULT 'Pending'
    );
    CREATE TABLE IF NOT EXISTS messages(
      id INTEGER PRIMARY KEY AUTOINCREMENT, sender_id INTEGER NOT NULL,
      receiver_id INTEGER NOT NULL, body TEXT NOT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS contracts(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      application_id INTEGER UNIQUE NOT NULL,
      job_id INTEGER NOT NULL,
      client_id INTEGER NOT NULL,
      professional_id INTEGER NOT NULL,
      title TEXT NOT NULL,
      terms TEXT DEFAULT '',
      budget TEXT DEFAULT '',
      status TEXT DEFAULT 'Active',
      platform_fee_percent REAL DEFAULT 10.0,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS milestones(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      contract_id INTEGER NOT NULL,
      title TEXT NOT NULL,
      description TEXT DEFAULT '',
      amount TEXT DEFAULT '',
      due_date TEXT DEFAULT '',
      status TEXT DEFAULT 'Pending',
      professional_verified INTEGER NOT NULL DEFAULT 0,
      client_verified INTEGER NOT NULL DEFAULT 0,
      professional_verified_at TIMESTAMP,
      client_verified_at TIMESTAMP,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS tasks(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      contract_id INTEGER NOT NULL,
      milestone_id INTEGER,
      title TEXT NOT NULL,
      description TEXT DEFAULT '',
      assigned_to INTEGER,
      due_date TEXT DEFAULT '',
      status TEXT DEFAULT 'To Do',
      priority TEXT DEFAULT 'Normal',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS deliverables(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      contract_id INTEGER NOT NULL,
      milestone_id INTEGER,
      task_id INTEGER,
      title TEXT NOT NULL,
      description TEXT DEFAULT '',
      submission_url TEXT DEFAULT '',
      submitted_by INTEGER NOT NULL,
      status TEXT DEFAULT 'Submitted',
      review_note TEXT DEFAULT '',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      reviewed_at TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS milestone_payments(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      contract_id INTEGER NOT NULL,
      milestone_id INTEGER UNIQUE NOT NULL,
      amount REAL NOT NULL DEFAULT 0,
      status TEXT DEFAULT 'Pending',
      released_at TIMESTAMP,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS contract_settlements(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      contract_id INTEGER UNIQUE NOT NULL,
      gross_amount REAL NOT NULL DEFAULT 0,
      platform_fee_percent REAL NOT NULL DEFAULT 10.0,
      platform_fee_amount REAL NOT NULL DEFAULT 0,
      professional_gross_released REAL NOT NULL DEFAULT 0,
      professional_net_amount REAL NOT NULL DEFAULT 0,
      status TEXT DEFAULT 'Pending',
      settled_at TIMESTAMP,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS contract_agreements(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      contract_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      role TEXT NOT NULL,
      agreement_version TEXT NOT NULL DEFAULT '1.0',
      accepted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      ip_address TEXT DEFAULT '',
      user_agent TEXT DEFAULT '',
      UNIQUE(contract_id, user_id)
    );
    CREATE TABLE IF NOT EXISTS disputes(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      contract_id INTEGER NOT NULL,
      milestone_id INTEGER,
      opened_by INTEGER NOT NULL,
      against_user_id INTEGER NOT NULL,
      reason TEXT NOT NULL,
      description TEXT DEFAULT '',
      evidence_url TEXT DEFAULT '',
      status TEXT DEFAULT 'Open',
      resolution TEXT DEFAULT '',
      resolved_by INTEGER,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      resolved_at TIMESTAMP
    );
        CREATE TABLE IF NOT EXISTS admin_audit_logs(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      admin_id INTEGER NOT NULL,
      action TEXT NOT NULL,
      target_type TEXT DEFAULT '',
      target_id INTEGER,
      details TEXT DEFAULT '',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """)
    # Lightweight SQLite migration for databases created by earlier increments.
    user_columns = {row[1] for row in c.execute("PRAGMA table_info(users)").fetchall()}
    if "account_status" not in user_columns:
        c.execute("ALTER TABLE users ADD COLUMN account_status TEXT DEFAULT 'Active'")
    existing = {row[1] for row in c.execute("PRAGMA table_info(deliverables)").fetchall()}
    migrations = {
        "task_id": "ALTER TABLE deliverables ADD COLUMN task_id INTEGER",
        "submission_url": "ALTER TABLE deliverables ADD COLUMN submission_url TEXT DEFAULT ''",
        "review_note": "ALTER TABLE deliverables ADD COLUMN review_note TEXT DEFAULT ''",
    }
    milestone_columns = {row[1] for row in c.execute("PRAGMA table_info(milestones)").fetchall()}
    milestone_migrations = {
        "professional_verified": "ALTER TABLE milestones ADD COLUMN professional_verified INTEGER NOT NULL DEFAULT 0",
        "client_verified": "ALTER TABLE milestones ADD COLUMN client_verified INTEGER NOT NULL DEFAULT 0",
        "professional_verified_at": "ALTER TABLE milestones ADD COLUMN professional_verified_at TIMESTAMP",
        "client_verified_at": "ALTER TABLE milestones ADD COLUMN client_verified_at TIMESTAMP",
    }
    for column, statement in milestone_migrations.items():
        if column not in milestone_columns:
            c.execute(statement)
    contract_columns = {row[1] for row in c.execute("PRAGMA table_info(contracts)").fetchall()}
    if "platform_fee_percent" not in contract_columns:
        c.execute("ALTER TABLE contracts ADD COLUMN platform_fee_percent REAL DEFAULT 10.0")
    for column, statement in migrations.items():
        if column not in existing:
            c.execute(statement)
    c.commit(); c.close()

def hp(p): return hashlib.sha256(p.encode()).hexdigest()

def money_value(value):
    """Convert common currency strings such as '₦100,000' or '$1,200' to float."""
    if value is None:
        return 0.0
    cleaned = re.sub(r"[^0-9.\-]", "", str(value))
    try:
        return float(cleaned) if cleaned else 0.0
    except ValueError:
        return 0.0
def user():
    if "uid" not in session: return None
    c=db(); u=c.execute("SELECT * FROM users WHERE id=?", (session["uid"],)).fetchone(); c.close()
    return u

@app.context_processor
def ctx(): return {"current_user": user(), "money_value": money_value}

def can_hire(u):
    return u and u["account_type"] in ("hire professional", "both", "Client", "Both")

def can_professional(u):
    return u and u["account_type"] in ("professional", "both", "Professional", "Both")

def is_admin(u):
    return bool(u and str(u["account_type"]).lower() == "admin")

def admin_required():
    u = user()
    if not u or not is_admin(u):
        flash("Administrator access is required.", "error")
        return None
    return u

def admin_log(admin_id, action, target_type="", target_id=None, details=""):
    c = db()
    c.execute(
        "INSERT INTO admin_audit_logs(admin_id,action,target_type,target_id,details) VALUES(?,?,?,?,?)",
        (admin_id, action, target_type, target_id, details)
    )
    c.commit()
    c.close()

@app.route("/")
def home(): return render_template("index.html")

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method=="POST":
        name=request.form.get("name","").strip()
        email=request.form.get("email","").strip().lower()
        password=request.form.get("password","")
        typ=request.form.get("account_type","both")
        if typ not in {"professional", "hire professional", "both"}:
            typ = "both"
        if not name or not re.match(r"^[^@]+@[^@]+\.[^@]+$",email) or len(password)<6:
            flash("Use a valid email and a password of at least 6 characters.","error")
            return redirect(url_for("register"))
        c=db()
        try:
            cur=c.execute("INSERT INTO users(name,email,password,account_type) VALUES(?,?,?,?)",(name,email,hp(password),typ))
            c.commit(); session["uid"]=cur.lastrowid
            flash("Account created.","success"); return redirect(url_for("dashboard"))
        except sqlite3.IntegrityError:
            flash("That email is already registered.","error")
        finally: c.close()
    return render_template("register.html")

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method=="POST":
        c=db(); u=c.execute("SELECT * FROM users WHERE email=? AND password=?",
                            (request.form.get("email","").lower(),hp(request.form.get("password","")))).fetchone(); c.close()
        if u:
            if "account_status" in u.keys() and u["account_status"] != "Active":
                flash("This account is currently suspended. Please contact TechConnect support.", "error")
                return redirect(url_for("login"))
            session["uid"]=u["id"]
            flash("Welcome back.","success")
            return redirect(url_for("admin_dashboard") if is_admin(u) else url_for("dashboard"))
        flash("Invalid email or password.","error")
    return render_template("login.html")

@app.route("/logout")
def logout(): session.clear(); return redirect(url_for("home"))

@app.route("/forgot-password", methods=["GET","POST"])
def forgot():
    if request.method=="POST": flash("Demo reset request received. Email delivery will be connected later.","success")
    return render_template("forgot_password.html")


@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        c = db()
        u = c.execute(
            "SELECT * FROM users WHERE email=? AND password=? AND lower(account_type)='admin'",
            (email, hp(password))
        ).fetchone()
        c.close()
        if u and (u["account_status"] if "account_status" in u.keys() else "Active") == "Active":
            session.clear()
            session["uid"] = u["id"]
            session["admin_uid"] = u["id"]
            admin_log(u["id"], "Admin login", "user", u["id"], "Successful administrator login")
            return redirect(url_for("admin_dashboard"))
        flash("Invalid administrator credentials.", "error")
    return render_template("admin_login.html")

@app.route("/admin")
def admin_dashboard():
    u = admin_required()
    if not u:
        return redirect(url_for("admin_login"))
    c = db()
    stats = {
        "users": c.execute("SELECT COUNT(*) n FROM users WHERE lower(account_type) <> 'admin'").fetchone()["n"],
        "professionals": c.execute("""SELECT COUNT(*) n FROM users
            WHERE lower(account_type) IN ('professional','both')""").fetchone()["n"],
        "clients": c.execute("""SELECT COUNT(*) n FROM users
            WHERE lower(account_type) IN ('hire professional','both','client')""").fetchone()["n"],
        "active_projects": c.execute("""SELECT COUNT(*) n FROM jobs
            WHERE lower(status) NOT IN ('completed','cancelled')""").fetchone()["n"],
        "contracts": c.execute("SELECT COUNT(*) n FROM contracts").fetchone()["n"],
        "active_contracts": c.execute("""SELECT COUNT(*) n FROM contracts
            WHERE lower(status) IN ('active','paused','awaiting agreement')""").fetchone()["n"],
        "disputes": c.execute("""SELECT COUNT(*) n FROM disputes
            WHERE lower(status) IN ('open','under review')""").fetchone()["n"],
        "released": c.execute("""SELECT COALESCE(SUM(amount),0) n FROM milestone_payments
            WHERE lower(status)='released'""").fetchone()["n"],
        "platform_fees": c.execute("""SELECT COALESCE(SUM(platform_fee_amount),0) n
            FROM contract_settlements WHERE lower(status)='settled'""").fetchone()["n"],
    }
    recent_users = c.execute("""SELECT id,name,email,account_type,
        COALESCE(account_status,'Active') account_status FROM users
        WHERE lower(account_type) <> 'admin' ORDER BY id DESC LIMIT 8""").fetchall()
    recent_contracts = c.execute("""SELECT contracts.*, client.name client_name,
        professional.name professional_name
        FROM contracts JOIN users client ON client.id=contracts.client_id
        JOIN users professional ON professional.id=contracts.professional_id
        ORDER BY contracts.id DESC LIMIT 8""").fetchall()
    recent_disputes = c.execute("""SELECT disputes.*, opener.name opener_name,
        against.name against_name, contracts.title contract_title
        FROM disputes JOIN users opener ON opener.id=disputes.opened_by
        JOIN users against ON against.id=disputes.against_user_id
        JOIN contracts ON contracts.id=disputes.contract_id
        ORDER BY disputes.id DESC LIMIT 8""").fetchall()
    logs = c.execute("""SELECT admin_audit_logs.*, users.name admin_name
        FROM admin_audit_logs JOIN users ON users.id=admin_audit_logs.admin_id
        ORDER BY admin_audit_logs.id DESC LIMIT 10""").fetchall()
    c.close()
    return render_template("admin_dashboard.html", stats=stats, recent_users=recent_users,
                           recent_contracts=recent_contracts, recent_disputes=recent_disputes, logs=logs)

@app.route("/admin/users")
def admin_users():
    u = admin_required()
    if not u: return redirect(url_for("admin_login"))
    q = request.args.get("q","").strip()
    status = request.args.get("status","")
    c = db()
    sql = """SELECT id,name,email,account_type,COALESCE(account_status,'Active') account_status,
             bio,github,portfolio FROM users WHERE lower(account_type) <> 'admin'"""
    params=[]
    if q:
        sql += " AND (name LIKE ? OR email LIKE ?)"
        params += [f"%{q}%", f"%{q}%"]
    if status in ("Active","Suspended"):
        sql += " AND COALESCE(account_status,'Active')=?"
        params.append(status)
    sql += " ORDER BY id DESC"
    users = c.execute(sql, params).fetchall()
    c.close()
    return render_template("admin_users.html", users=users, q=q, status=status)

@app.route("/admin/users/<int:user_id>/status", methods=["POST"])
def admin_user_status(user_id):
    u = admin_required()
    if not u: return redirect(url_for("admin_login"))
    new_status = request.form.get("status","")
    if new_status not in ("Active","Suspended"):
        flash("Invalid account status.", "error")
        return redirect(url_for("admin_users"))
    c=db()
    target=c.execute("SELECT * FROM users WHERE id=? AND lower(account_type)<>'admin'",(user_id,)).fetchone()
    if not target:
        c.close(); flash("User not found.", "error"); return redirect(url_for("admin_users"))
    c.execute("UPDATE users SET account_status=? WHERE id=?", (new_status,user_id))
    c.commit(); c.close()
    admin_log(u["id"], f"User status changed to {new_status}", "user", user_id, target["email"])
    flash(f"{target['name']} is now {new_status.lower()}.", "success")
    return redirect(request.referrer or url_for("admin_users"))

@app.route("/admin/projects")
def admin_projects():
    u = admin_required()
    if not u: return redirect(url_for("admin_login"))
    c=db()
    projects=c.execute("""SELECT jobs.*, users.name client_name, users.email client_email,
        (SELECT COUNT(*) FROM applications WHERE applications.job_id=jobs.id) application_count
        FROM jobs JOIN users ON users.id=jobs.client_id ORDER BY jobs.id DESC""").fetchall()
    c.close()
    return render_template("admin_projects.html", projects=projects)

@app.route("/admin/contracts")
def admin_contracts():
    u = admin_required()
    if not u: return redirect(url_for("admin_login"))
    c=db()
    contracts=c.execute("""SELECT contracts.*, client.name client_name, professional.name professional_name,
        COALESCE((SELECT SUM(amount) FROM milestone_payments mp
                  WHERE mp.contract_id=contracts.id AND lower(mp.status)='released'),0) released_amount,
        COALESCE((SELECT COUNT(*) FROM milestones m WHERE m.contract_id=contracts.id),0) milestone_count
        FROM contracts
        JOIN users client ON client.id=contracts.client_id
        JOIN users professional ON professional.id=contracts.professional_id
        ORDER BY contracts.id DESC""").fetchall()
    c.close()
    return render_template("admin_contracts.html", contracts=contracts)

@app.route("/admin/disputes")
def admin_disputes():
    u = admin_required()
    if not u: return redirect(url_for("admin_login"))
    c=db()
    disputes=c.execute("""SELECT disputes.*, opener.name opener_name,
        against.name against_name, contracts.title contract_title
        FROM disputes
        JOIN users opener ON opener.id=disputes.opened_by
        JOIN users against ON against.id=disputes.against_user_id
        JOIN contracts ON contracts.id=disputes.contract_id
        ORDER BY CASE WHEN lower(disputes.status) IN ('open','under review') THEN 0 ELSE 1 END, disputes.id DESC""").fetchall()
    c.close()
    return render_template("admin_disputes.html", disputes=disputes)

@app.route("/admin/disputes/<int:dispute_id>/resolve", methods=["POST"])
def admin_resolve_dispute(dispute_id):
    u = admin_required()
    if not u: return redirect(url_for("admin_login"))
    resolution=request.form.get("resolution","").strip()
    status=request.form.get("status","Resolved")
    if status not in ("Under Review","Resolved","Closed"):
        status="Resolved"
    if not resolution:
        flash("A resolution note is required.", "error")
        return redirect(url_for("admin_disputes"))
    c=db()
    d=c.execute("SELECT * FROM disputes WHERE id=?",(dispute_id,)).fetchone()
    if not d:
        c.close(); flash("Dispute not found.","error"); return redirect(url_for("admin_disputes"))
    c.execute("""UPDATE disputes SET status=?, resolution=?, resolved_by=?,
        resolved_at=CURRENT_TIMESTAMP WHERE id=?""",
        (status,resolution,u["id"],dispute_id))
    c.commit(); c.close()
    admin_log(u["id"], f"Dispute {status.lower()}", "dispute", dispute_id, resolution)
    flash("Dispute updated.", "success")
    return redirect(url_for("admin_disputes"))

@app.route("/admin/audit")
def admin_audit():
    u = admin_required()
    if not u: return redirect(url_for("admin_login"))
    c=db()
    logs=c.execute("""SELECT admin_audit_logs.*, users.name admin_name
        FROM admin_audit_logs JOIN users ON users.id=admin_audit_logs.admin_id
        ORDER BY admin_audit_logs.id DESC LIMIT 200""").fetchall()
    c.close()
    return render_template("admin_audit.html", logs=logs)

@app.route("/discover")
def discover():
    q=request.args.get("q","").lower().strip()
    c=db(); users=c.execute("SELECT * FROM users WHERE account_type IN ('Professional','Both')").fetchall(); c.close()
    if q: users=[u for u in users if q in (u["name"]+" "+u["bio"]+" "+u["github"]+" "+u["portfolio"]).lower()]
    return render_template("discover.html",professionals=users,query=q)

@app.route("/dashboard")
def dashboard():
    u=user()
    if not u: return redirect(url_for("login"))
    c=db()
    jobs=c.execute("SELECT * FROM jobs WHERE client_id=? ORDER BY id DESC",(u["id"],)).fetchall()
    mine=c.execute("""SELECT applications.*,jobs.title FROM applications JOIN jobs ON jobs.id=applications.job_id
                      WHERE applications.professional_id=? ORDER BY applications.id DESC""",(u["id"],)).fetchall()
    received=c.execute("""SELECT applications.*,jobs.title,users.name professional_name
                          FROM applications JOIN jobs ON jobs.id=applications.job_id
                          JOIN users ON users.id=applications.professional_id
                          WHERE jobs.client_id=? ORDER BY applications.id DESC""",(u["id"],)).fetchall()
    c.close()
    return render_template("dashboard.html",jobs=jobs,mine=mine,received=received)

@app.route("/profile", methods=["GET","POST"])
def profile():
    u=user()
    if not u: return redirect(url_for("login"))
    if request.method=="POST":
        c=db(); c.execute("UPDATE users SET bio=?,github=?,portfolio=? WHERE id=?",
                          (request.form.get("bio",""),request.form.get("github",""),request.form.get("portfolio",""),u["id"]))
        c.commit(); c.close(); flash("Profile saved.","success")
    return render_template("profile.html")

@app.route("/jobs/new", methods=["GET","POST"])
def new_job():
    u=user()
    if not u: return redirect(url_for("login"))
    if not can_hire(u):
        flash("Your account is not enabled for hiring features.", "error")
        return redirect(url_for("dashboard"))
    if request.method=="POST":
        if not request.form.get("title") or not request.form.get("description"):
            flash("Title and description are required.","error")
        else:
            c=db(); c.execute("INSERT INTO jobs(client_id,title,category,description,budget) VALUES(?,?,?,?,?)",
                              (u["id"],request.form["title"],request.form["category"],request.form["description"],request.form.get("budget","")))
            c.commit(); c.close(); flash("Job posted.","success"); return redirect(url_for("dashboard"))
    return render_template("new_job.html")

@app.route("/jobs")
def jobs():
    c=db(); rows=c.execute("""SELECT jobs.*,users.name client_name FROM jobs JOIN users ON users.id=jobs.client_id
                              WHERE jobs.status='Open' ORDER BY jobs.id DESC""").fetchall(); c.close()
    return render_template("jobs.html",jobs=rows)

@app.route("/jobs/<int:jid>/apply", methods=["GET", "POST"])
def apply(jid):
    u=user()
    if not u: return redirect(url_for("login"))
    if not can_professional(u):
        flash("Only professional-enabled accounts can submit proposals.", "error")
        return redirect(url_for("jobs"))
    c=db()
    job=c.execute("SELECT jobs.*, users.name client_name FROM jobs JOIN users ON users.id=jobs.client_id WHERE jobs.id=?", (jid,)).fetchone()
    if not job:
        c.close(); flash("Job not found.", "error"); return redirect(url_for("jobs"))
    if u["id"] == job["client_id"]:
        c.close(); flash("You cannot submit a proposal to your own job.", "error"); return redirect(url_for("jobs"))
    existing=c.execute("SELECT * FROM applications WHERE job_id=? AND professional_id=?",(jid,u["id"])).fetchone()
    if request.method == "GET":
        c.close()
        return render_template("proposal.html", job=job, existing=existing)
    if existing:
        c.close(); flash("You already submitted a proposal for this project.","error"); return redirect(url_for("application_detail", aid=existing["id"]))
    message=request.form.get("message", "").strip()
    if len(message) < 20:
        c.close(); flash("Please provide a proposal of at least 20 characters.", "error")
        return redirect(url_for("apply", jid=jid))
    c.execute("INSERT INTO applications(job_id,professional_id,message) VALUES(?,?,?)",(jid,u["id"],message))
    aid=c.execute("SELECT last_insert_rowid()").fetchone()[0]
    c.commit(); c.close(); flash("Proposal submitted successfully.","success")
    return redirect(url_for("application_detail", aid=aid))

@app.route("/applications/<int:aid>")
def application_detail(aid):
    u=user()
    if not u: return redirect(url_for("login"))
    c=db()
    row=c.execute("""SELECT applications.*, jobs.title, jobs.category, jobs.description, jobs.budget, jobs.client_id,
                           jobs.status job_status, client.name client_name, professional.name professional_name,
                           professional.bio professional_bio, professional.github professional_github, professional.portfolio professional_portfolio
                    FROM applications JOIN jobs ON jobs.id=applications.job_id
                    JOIN users client ON client.id=jobs.client_id
                    JOIN users professional ON professional.id=applications.professional_id
                    WHERE applications.id=? AND (jobs.client_id=? OR applications.professional_id=?)""", (aid,u["id"],u["id"])).fetchone()
    c.close()
    if not row:
        flash("Proposal not found or you do not have access to it.", "error")
        return redirect(url_for("dashboard"))
    return render_template("proposal_detail.html", proposal=row)

@app.route("/applications/<int:aid>/<action>")
def app_action(aid,action):
    u=user()
    if not u: return redirect(url_for("login"))
    if action not in ("accept","reject"): return redirect(url_for("dashboard"))
    c=db(); row=c.execute("""SELECT applications.id FROM applications JOIN jobs ON jobs.id=applications.job_id
                             WHERE applications.id=? AND jobs.client_id=?""",(aid,u["id"])).fetchone()
    if row:
        new_status = "Accepted" if action == "accept" else "Rejected"
        c.execute("UPDATE applications SET status=? WHERE id=?", (new_status, aid))

        # An accepted application becomes the starting point for a contract.
        # The contract is created only once, so refreshing the action cannot
        # create duplicate contracts.
        if action == "accept":
            contract = c.execute(
                "SELECT id FROM contracts WHERE application_id=?", (aid,)
            ).fetchone()
            if not contract:
                details = c.execute("""SELECT
                    applications.job_id, applications.professional_id,
                    jobs.client_id, jobs.title, jobs.budget
                    FROM applications
                    JOIN jobs ON jobs.id = applications.job_id
                    WHERE applications.id=?""", (aid,)).fetchone()
                if details:
                    c.execute("""INSERT INTO contracts
                        (application_id,job_id,client_id,professional_id,title,budget,status)
                        VALUES(?,?,?,?,?,?,?)""", (
                            aid, details["job_id"], details["client_id"],
                            details["professional_id"], details["title"],
                            details["budget"], "Awaiting Agreement"
                        ))
        c.commit()
    c.close(); return redirect(url_for("dashboard"))

@app.route("/contracts/<int:contract_id>/accept-agreement", methods=["POST"])
def accept_contract_agreement(contract_id):
    u = user()
    if not u:
        return redirect(url_for("login"))
    c = db()
    contract = c.execute("SELECT * FROM contracts WHERE id=? AND (client_id=? OR professional_id=?)", (contract_id, u["id"], u["id"])).fetchone()
    if not contract:
        c.close(); flash("Contract not found or you do not have access to it.", "error"); return redirect(url_for("contracts"))

    role = "client" if u["id"] == contract["client_id"] else "professional"
    version = "1.0"
    c.execute("""INSERT INTO contract_agreements
        (contract_id,user_id,role,agreement_version,ip_address,user_agent)
        VALUES(?,?,?,?,?,?)
        ON CONFLICT(contract_id,user_id) DO UPDATE SET
          role=excluded.role, agreement_version=excluded.agreement_version,
          accepted_at=CURRENT_TIMESTAMP, ip_address=excluded.ip_address, user_agent=excluded.user_agent""",
        (contract_id, u["id"], role, version, request.remote_addr or "", request.headers.get("User-Agent", "")))

    accepted = c.execute("SELECT COUNT(*) AS n FROM contract_agreements WHERE contract_id=?", (contract_id,)).fetchone()["n"]
    if accepted >= 2 and contract["status"] == "Awaiting Agreement":
        c.execute("UPDATE contracts SET status='Active', updated_at=CURRENT_TIMESTAMP WHERE id=?", (contract_id,))
        flash("Both parties have accepted the agreement. The contract is now Active.", "success")
    else:
        flash("Your agreement has been recorded. The contract will become Active after the other party accepts.", "success")
    c.commit(); c.close()
    return redirect(url_for("contract_detail", contract_id=contract_id))


@app.route("/contracts")
def contracts():
    u = user()
    if not u:
        return redirect(url_for("login"))

    c = db()
    rows = c.execute("""SELECT contracts.*,
        client.name AS client_name,
        professional.name AS professional_name
        FROM contracts
        JOIN users AS client ON client.id = contracts.client_id
        JOIN users AS professional ON professional.id = contracts.professional_id
        WHERE contracts.client_id=? OR contracts.professional_id=?
        ORDER BY contracts.id DESC""", (u["id"], u["id"])).fetchall()
    c.close()
    return render_template("contracts.html", contracts=rows)


@app.route("/contracts/<int:contract_id>", methods=["GET", "POST"])
def contract_detail(contract_id):
    u = user()
    if not u:
        return redirect(url_for("login"))

    c = db()
    contract = c.execute("""SELECT contracts.*,
        client.name AS client_name,
        professional.name AS professional_name
        FROM contracts
        JOIN users AS client ON client.id = contracts.client_id
        JOIN users AS professional ON professional.id = contracts.professional_id
        WHERE contracts.id=?
          AND (contracts.client_id=? OR contracts.professional_id=?)""",
        (contract_id, u["id"], u["id"])).fetchone()

    if not contract:
        c.close()
        flash("Contract not found or you do not have access to it.", "error")
        return redirect(url_for("contracts"))

    agreement_rows = c.execute("SELECT * FROM contract_agreements WHERE contract_id=? ORDER BY accepted_at", (contract_id,)).fetchall()
    my_agreement = c.execute("SELECT * FROM contract_agreements WHERE contract_id=? AND user_id=?", (contract_id, u["id"])).fetchone()
    agreement_count = len(agreement_rows)

    if request.method == "POST":
        if contract["status"] == "Awaiting Agreement" and agreement_count > 0:
            c.close()
            flash("The contract cannot be changed after one party has accepted the agreement.", "error")
            return redirect(url_for("contract_detail", contract_id=contract_id))
        terms = request.form.get("terms", "").strip()
        budget = request.form.get("budget", "").strip()
        status = request.form.get("status", contract["status"])

        allowed_statuses = {"Active", "Paused", "Completed", "Cancelled"}
        if contract["status"] == "Awaiting Agreement":
            status = "Awaiting Agreement"
        if status not in allowed_statuses:
            status = contract["status"]
        if contract["status"] == "Awaiting Agreement":
            status = "Awaiting Agreement"

        # Both parties can update the working terms for now. Authorization
        # rules can be tightened later when approvals/signatures are added.
        if status == "Completed":
            # Final closure is a client-side action. The professional's role is
            # to complete/verify milestones; the hiring client closes the deal
            # after all financial and dispute conditions are satisfied.
            if u["id"] != contract["client_id"]:
                c.close()
                flash("Only the hiring client can mark the contract as Completed.", "error")
                return redirect(url_for("contract_detail", contract_id=contract_id))
            if contract["status"] != "Active":
                c.close()
                flash("Only an Active contract can be completed.", "error")
                return redirect(url_for("contract_detail", contract_id=contract_id))

            milestone_count = c.execute(
                "SELECT COUNT(*) AS n FROM milestones WHERE contract_id=?",
                (contract_id,)
            ).fetchone()["n"]
            incomplete = c.execute(
                "SELECT COUNT(*) AS n FROM milestones WHERE contract_id=? AND status <> 'Completed'",
                (contract_id,)
            ).fetchone()["n"]
            unreleased = c.execute(
                "SELECT COUNT(*) AS n FROM milestone_payments WHERE contract_id=? AND status <> 'Released'",
                (contract_id,)
            ).fetchone()["n"]
            open_disputes = c.execute(
                "SELECT COUNT(*) AS n FROM disputes WHERE contract_id=? AND status IN ('Open','Under Review')",
                (contract_id,)
            ).fetchone()["n"]
            pending_deliverables = c.execute(
                "SELECT COUNT(*) AS n FROM deliverables WHERE contract_id=? AND status IN ('Submitted','Revision Requested')",
                (contract_id,)
            ).fetchone()["n"]
            if milestone_count == 0 or incomplete or unreleased or open_disputes or pending_deliverables:
                c.close()
                flash("Before closing: create milestones, complete and fully verify every milestone, release every milestone payment, finish deliverable reviews, and resolve all open disputes.", "error")
                return redirect(url_for("contract_detail", contract_id=contract_id))

            # The final settlement is based on the agreed contract value.
            gross_check = money_value(contract["budget"])
            released_check = c.execute(
                "SELECT COALESCE(SUM(amount),0) AS total FROM milestone_payments WHERE contract_id=? AND status='Released'",
                (contract_id,)
            ).fetchone()["total"] or 0
            if gross_check > 0 and released_check + 0.01 < gross_check:
                c.close()
                flash("The released milestone payments do not yet cover the agreed contract value. Complete the remaining financial releases before closing the contract.", "error")
                return redirect(url_for("contract_detail", contract_id=contract_id))

        c.execute("""UPDATE contracts
            SET terms=?, budget=?, status=?, updated_at=CURRENT_TIMESTAMP
            WHERE id=?""", (terms, budget, status, contract_id))

        # The TechConnect platform fee is NOT deducted from milestone releases.
        # It is recorded only when the entire contract is completed.
        if status == "Completed":
            gross = money_value(budget)
            fee_percent = float(contract["platform_fee_percent"] or 10.0)
            fee_amount = round(gross * fee_percent / 100.0, 2)
            released = c.execute(
                "SELECT COALESCE(SUM(amount),0) AS total FROM milestone_payments WHERE contract_id=? AND status='Released'",
                (contract_id,)
            ).fetchone()["total"]
            net = round(gross - fee_amount, 2)
            c.execute("""INSERT INTO contract_settlements
                (contract_id,gross_amount,platform_fee_percent,platform_fee_amount,professional_gross_released,professional_net_amount,status,settled_at)
                VALUES(?,?,?,?,?,?, 'Settled', CURRENT_TIMESTAMP)
                ON CONFLICT(contract_id) DO UPDATE SET
                  gross_amount=excluded.gross_amount,
                  platform_fee_percent=excluded.platform_fee_percent,
                  platform_fee_amount=excluded.platform_fee_amount,
                  professional_gross_released=excluded.professional_gross_released,
                  professional_net_amount=excluded.professional_net_amount,
                  status='Settled', settled_at=CURRENT_TIMESTAMP""",
                (contract_id, gross, fee_percent, fee_amount, released, net))

        c.commit()
        c.close()
        flash("Contract updated. Final 10% platform fee is settled only when the whole contract is completed." if status == "Completed" else "Contract updated.", "success")
        return redirect(url_for("contract_detail", contract_id=contract_id))

    milestones = c.execute("SELECT * FROM milestones WHERE contract_id=? ORDER BY id DESC", (contract_id,)).fetchall()
    tasks = c.execute("SELECT tasks.*,users.name assigned_name FROM tasks LEFT JOIN users ON users.id=tasks.assigned_to WHERE tasks.contract_id=? ORDER BY tasks.id DESC", (contract_id,)).fetchall()
    deliverables = c.execute("""SELECT deliverables.*, users.name submitted_name,
        milestones.title milestone_title, tasks.title task_title
        FROM deliverables
        JOIN users ON users.id=deliverables.submitted_by
        LEFT JOIN milestones ON milestones.id=deliverables.milestone_id
        LEFT JOIN tasks ON tasks.id=deliverables.task_id
        WHERE deliverables.contract_id=? ORDER BY deliverables.id DESC""", (contract_id,)).fetchall()
    milestone_payments = c.execute("""SELECT milestone_payments.*, milestones.title milestone_title
        FROM milestone_payments JOIN milestones ON milestones.id=milestone_payments.milestone_id
        WHERE milestone_payments.contract_id=? ORDER BY milestone_payments.id DESC""", (contract_id,)).fetchall()
    settlement = c.execute("SELECT * FROM contract_settlements WHERE contract_id=?", (contract_id,)).fetchone()
    disputes = c.execute("""SELECT disputes.*, opener.name opened_by_name, opponent.name against_name,
        milestones.title milestone_title
        FROM disputes
        JOIN users AS opener ON opener.id=disputes.opened_by
        JOIN users AS opponent ON opponent.id=disputes.against_user_id
        LEFT JOIN milestones ON milestones.id=disputes.milestone_id
        WHERE disputes.contract_id=? ORDER BY disputes.id DESC""", (contract_id,)).fetchall()
    released_total = c.execute("SELECT COALESCE(SUM(amount),0) AS total FROM milestone_payments WHERE contract_id=? AND status='Released'", (contract_id,)).fetchone()["total"]
    milestone_total = c.execute("SELECT COALESCE(SUM(CAST(REPLACE(REPLACE(REPLACE(amount,'₦',''),',',''),'$','') AS REAL)),0) AS total FROM milestones WHERE contract_id=?", (contract_id,)).fetchone()["total"]
    c.close()
    fee_percent = float(contract["platform_fee_percent"] or 10.0)
    gross = money_value(contract["budget"])
    fee_amount = round(gross * fee_percent / 100.0, 2)
    net_amount = round(gross - fee_amount, 2)
    return render_template("contract_detail.html", contract=contract, milestones=milestones, tasks=tasks, deliverables=deliverables, disputes=disputes, fee_percent=fee_percent, milestone_payments=milestone_payments, settlement=settlement, released_total=released_total, milestone_total=milestone_total, fee_amount=fee_amount, net_amount=net_amount, agreement_rows=agreement_rows, my_agreement=my_agreement, agreement_count=agreement_count, agreement_version="1.0")


@app.route("/contracts/<int:contract_id>/workspace")
def project_workspace(contract_id):
    u = user()
    if not u:
        return redirect(url_for("login"))
    c = db()
    contract = c.execute("""SELECT contracts.*, client.name client_name, professional.name professional_name
        FROM contracts JOIN users client ON client.id=contracts.client_id
        JOIN users professional ON professional.id=contracts.professional_id
        WHERE contracts.id=? AND (contracts.client_id=? OR contracts.professional_id=?)""",
        (contract_id, u["id"], u["id"])).fetchone()
    if not contract:
        c.close(); flash("Workspace not found or you do not have access to it.", "error")
        return redirect(url_for("contracts"))
    if contract["status"] != "Active":
        c.close(); flash("The project workspace becomes available after both parties accept the agreement.", "error")
        return redirect(url_for("contract_detail", contract_id=contract_id))
    milestones = c.execute("SELECT * FROM milestones WHERE contract_id=? ORDER BY id ASC", (contract_id,)).fetchall()
    tasks = c.execute("""SELECT tasks.*, users.name assigned_name FROM tasks
        LEFT JOIN users ON users.id=tasks.assigned_to WHERE tasks.contract_id=? ORDER BY tasks.id DESC""", (contract_id,)).fetchall()
    deliverables = c.execute("""SELECT deliverables.*, users.name submitted_name, milestones.title milestone_title
        FROM deliverables JOIN users ON users.id=deliverables.submitted_by
        LEFT JOIN milestones ON milestones.id=deliverables.milestone_id
        WHERE deliverables.contract_id=? ORDER BY deliverables.id DESC""", (contract_id,)).fetchall()
    payments = c.execute("""SELECT milestone_payments.*, milestones.title milestone_title
        FROM milestone_payments JOIN milestones ON milestones.id=milestone_payments.milestone_id
        WHERE milestone_payments.contract_id=? ORDER BY milestone_payments.id DESC""", (contract_id,)).fetchall()
    message_count = c.execute("""SELECT COUNT(*) n FROM messages
        WHERE (sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?)""",
        (u["id"], contract["client_id"] if u["id"]==contract["professional_id"] else contract["professional_id"],
         contract["client_id"] if u["id"]==contract["professional_id"] else contract["professional_id"], u["id"])).fetchone()["n"]
    completed = sum(1 for m in milestones if m["status"] == "Completed")
    verified = sum(1 for m in milestones if m["professional_verified"] and m["client_verified"])
    paid = sum(1 for p in payments if p["status"] == "Released")
    c.close()
    return render_template("workspace.html", contract=contract, milestones=milestones, tasks=tasks,
                           deliverables=deliverables, payments=payments, message_count=message_count,
                           completed=completed, verified=verified, paid=paid)

@app.route("/contracts/<int:contract_id>/milestones")
def milestones_page(contract_id):
    u=user()
    if not u: return redirect(url_for("login"))
    c=db()
    contract=c.execute("""SELECT contracts.*, client.name client_name, professional.name professional_name
                        FROM contracts
                        JOIN users client ON client.id=contracts.client_id
                        JOIN users professional ON professional.id=contracts.professional_id
                        WHERE contracts.id=? AND (contracts.client_id=? OR contracts.professional_id=?)""",
                       (contract_id,u["id"],u["id"])).fetchone()
    if not contract:
        c.close(); flash("Contract not found or you do not have access to it.", "error"); return redirect(url_for("contracts"))
    milestones=c.execute("SELECT * FROM milestones WHERE contract_id=? ORDER BY id ASC", (contract_id,)).fetchall()
    payments=c.execute("""SELECT milestone_payments.*, milestones.title milestone_title
                         FROM milestone_payments JOIN milestones ON milestones.id=milestone_payments.milestone_id
                         WHERE milestone_payments.contract_id=?""", (contract_id,)).fetchall()
    payment_by_milestone={p["milestone_id"]:p for p in payments}
    c.close()
    total=sum(money_value(m["amount"]) for m in milestones)
    released=sum(money_value(p["amount"]) for p in payments if p["status"]=="Released")
    return render_template("milestones.html", contract=contract, milestones=milestones, payment_by_milestone=payment_by_milestone, total=total, released=released)

@app.route("/contracts/<int:contract_id>/milestones/new", methods=["POST"])
def create_milestone(contract_id):
    u=user()
    if not u: return redirect(url_for("login"))
    c=db()
    contract=c.execute("SELECT * FROM contracts WHERE id=? AND (client_id=? OR professional_id=?)",(contract_id,u["id"],u["id"])).fetchone()
    if not contract:
        c.close(); flash("Contract not found.","error"); return redirect(url_for("contracts"))
    if contract["status"] not in {"Active", "Paused"}:
        c.close(); flash("Milestones can only be added to an Active or Paused contract.", "error"); return redirect(url_for("contract_detail",contract_id=contract_id))
    title=request.form.get("title","").strip()
    amount=request.form.get("amount","").strip()
    if not title:
        c.close(); flash("Milestone title is required.","error"); return redirect(url_for("contract_detail",contract_id=contract_id))
    if amount and money_value(amount) <= 0:
        c.close(); flash("Milestone amount must be a valid positive amount.", "error"); return redirect(url_for("contract_detail",contract_id=contract_id))
    existing_total = c.execute("SELECT COALESCE(SUM(CAST(REPLACE(REPLACE(REPLACE(amount,'₦',''),',',''),'$','') AS REAL)),0) AS total FROM milestones WHERE contract_id=?", (contract_id,)).fetchone()["total"] or 0
    contract_total = money_value(contract["budget"])
    if contract_total and existing_total + money_value(amount) > contract_total + 0.01:
        c.close(); flash("Milestone amounts cannot exceed the agreed contract value.", "error"); return redirect(url_for("contract_detail",contract_id=contract_id))
    c.execute("INSERT INTO milestones(contract_id,title,description,amount,due_date) VALUES(?,?,?,?,?)",(contract_id,title,request.form.get("description","").strip(),amount,request.form.get("due_date","").strip()))
    c.commit(); c.close(); flash("Milestone created.","success"); return redirect(url_for("contract_detail",contract_id=contract_id))

@app.route("/milestones/<int:milestone_id>/release-payment", methods=["POST"])
def release_milestone_payment(milestone_id):
    u = user()
    if not u:
        return redirect(url_for("login"))
    c = db()
    m = c.execute("""SELECT milestones.*, contracts.client_id, contracts.professional_id, contracts.budget
        FROM milestones JOIN contracts ON contracts.id=milestones.contract_id
        WHERE milestones.id=? AND (contracts.client_id=? OR contracts.professional_id=?)""",
        (milestone_id, u["id"], u["id"])).fetchone()
    if not m:
        c.close(); flash("Milestone not found.", "error"); return redirect(url_for("dashboard"))
    if u["id"] != m["client_id"]:
        c.close(); flash("Only the hiring client can release milestone payments.", "error"); return redirect(url_for("contract_detail", contract_id=m["contract_id"]))
    if m["status"] != "Completed":
        c.close(); flash("The milestone must be marked completed before its payment can be released.", "error"); return redirect(url_for("contract_detail", contract_id=m["contract_id"]))
    if not m["professional_verified"] or not m["client_verified"]:
        c.close(); flash("Both the professional and hiring client must verify this milestone as completed before payment can be released.", "error"); return redirect(url_for("contract_detail", contract_id=m["contract_id"]))
    open_dispute = c.execute(
        "SELECT id FROM disputes WHERE milestone_id=? AND status IN ('Open','Under Review')",
        (milestone_id,)
    ).fetchone()
    if open_dispute:
        c.close(); flash("This milestone has an open dispute. Resolve the dispute before releasing its payment.", "error"); return redirect(url_for("contract_detail", contract_id=m["contract_id"]))
    amount = money_value(m["amount"])
    if amount <= 0:
        c.close(); flash("Set a valid milestone amount before releasing payment.", "error"); return redirect(url_for("contract_detail", contract_id=m["contract_id"]))
    existing = c.execute("SELECT * FROM milestone_payments WHERE milestone_id=?", (milestone_id,)).fetchone()
    if existing and existing["status"] == "Released":
        c.close(); flash("This milestone payment has already been released.", "error"); return redirect(url_for("contract_detail", contract_id=m["contract_id"]))
    contract_total = money_value(m["budget"])
    released = c.execute("SELECT COALESCE(SUM(amount),0) AS total FROM milestone_payments WHERE contract_id=? AND status='Released'", (m["contract_id"],)).fetchone()["total"]
    if contract_total and released + amount > contract_total + 0.01:
        c.close(); flash("Milestone releases cannot exceed the total contract value.", "error"); return redirect(url_for("contract_detail", contract_id=m["contract_id"]))
    c.execute("""INSERT INTO milestone_payments(contract_id,milestone_id,amount,status,released_at)
        VALUES(?,?,?,?,CURRENT_TIMESTAMP)
        ON CONFLICT(milestone_id) DO UPDATE SET amount=excluded.amount,status='Released',released_at=CURRENT_TIMESTAMP""",
        (m["contract_id"], milestone_id, amount, "Released"))
    c.commit(); c.close()
    flash(f"Milestone payment released to the professional: {amount:,.2f}. No 10% platform fee was deducted from this milestone.", "success")
    return redirect(url_for("contract_detail", contract_id=m["contract_id"]))

@app.route("/contracts/<int:contract_id>/tasks/new", methods=["POST"])
def create_task(contract_id):
    u=user()
    if not u: return redirect(url_for("login"))
    c=db()
    contract=c.execute("SELECT * FROM contracts WHERE id=? AND (client_id=? OR professional_id=?)",(contract_id,u["id"],u["id"])).fetchone()
    if not contract:
        c.close(); flash("Contract not found.","error"); return redirect(url_for("contracts"))
    title=request.form.get("title","").strip()
    if not title:
        c.close(); flash("Task title is required.","error"); return redirect(url_for("contract_detail",contract_id=contract_id))
    milestone_id=request.form.get("milestone_id") or None
    if milestone_id and not c.execute("SELECT id FROM milestones WHERE id=? AND contract_id=?", (milestone_id, contract_id)).fetchone():
        c.close(); flash("Selected milestone does not belong to this contract.", "error"); return redirect(url_for("contract_detail",contract_id=contract_id))
    assigned_to=request.form.get("assigned_to") or None
    if assigned_to and not c.execute("SELECT id FROM users WHERE id IN (?,?) AND id=?", (contract["client_id"], contract["professional_id"], assigned_to)).fetchone():
        c.close(); flash("Tasks can only be assigned to one of the two contract parties.", "error"); return redirect(url_for("contract_detail",contract_id=contract_id))
    priority=request.form.get("priority","Normal")
    if priority not in {"Low","Normal","High","Urgent"}: priority="Normal"
    c.execute("INSERT INTO tasks(contract_id,milestone_id,title,description,assigned_to,due_date,priority) VALUES(?,?,?,?,?,?,?)",(contract_id,milestone_id,title,request.form.get("description","").strip(),assigned_to,request.form.get("due_date","").strip(),priority))
    c.commit(); c.close(); flash("Task created.","success"); return redirect(url_for("contract_detail",contract_id=contract_id))

@app.route("/tasks/<int:task_id>/status", methods=["POST"])
def update_task_status(task_id):
    u=user()
    if not u: return redirect(url_for("login"))
    c=db()
    task=c.execute("SELECT tasks.*,contracts.client_id,contracts.professional_id FROM tasks JOIN contracts ON contracts.id=tasks.contract_id WHERE tasks.id=? AND (contracts.client_id=? OR contracts.professional_id=?)",(task_id,u["id"],u["id"])).fetchone()
    if not task:
        c.close(); flash("Task not found.","error"); return redirect(url_for("dashboard"))
    status=request.form.get("status","To Do")
    if status not in {"To Do","In Progress","Blocked","Done"}: status=task["status"]
    c.execute("UPDATE tasks SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",(status,task_id)); c.commit(); c.close()
    return redirect(url_for("contract_detail",contract_id=task["contract_id"]))

@app.route("/milestones/<int:milestone_id>/verify-completion", methods=["POST"])
def verify_milestone_completion(milestone_id):
    u = user()
    if not u:
        return redirect(url_for("login"))
    c = db()
    m = c.execute("""SELECT milestones.*, contracts.client_id, contracts.professional_id
        FROM milestones JOIN contracts ON contracts.id=milestones.contract_id
        WHERE milestones.id=? AND (contracts.client_id=? OR contracts.professional_id=?)""",
        (milestone_id, u["id"], u["id"])).fetchone()
    if not m:
        c.close(); flash("Milestone not found.", "error"); return redirect(url_for("dashboard"))
    if m["status"] != "Completed":
        c.close(); flash("Mark the milestone as completed before verification.", "error"); return redirect(url_for("contract_detail", contract_id=m["contract_id"]))
    if u["id"] == m["client_id"]:
        c.execute("UPDATE milestones SET client_verified=1, client_verified_at=CURRENT_TIMESTAMP, updated_at=CURRENT_TIMESTAMP WHERE id=?", (milestone_id,))
        message = "Your completion verification has been recorded. The professional must also verify this milestone before payment can be released."
    elif u["id"] == m["professional_id"]:
        c.execute("UPDATE milestones SET professional_verified=1, professional_verified_at=CURRENT_TIMESTAMP, updated_at=CURRENT_TIMESTAMP WHERE id=?", (milestone_id,))
        message = "Your completion verification has been recorded. The hiring client must also verify this milestone before payment can be released."
    else:
        c.close(); flash("You are not a party to this milestone.", "error"); return redirect(url_for("dashboard"))
    c.commit(); c.close(); flash(message, "success")
    return redirect(url_for("contract_detail", contract_id=m["contract_id"]))

@app.route("/milestones/<int:milestone_id>/status", methods=["POST"])
def update_milestone_status(milestone_id):
    u=user()
    if not u: return redirect(url_for("login"))
    c=db()
    m=c.execute("SELECT milestones.*,contracts.client_id,contracts.professional_id FROM milestones JOIN contracts ON contracts.id=milestones.contract_id WHERE milestones.id=? AND (contracts.client_id=? OR contracts.professional_id=?)",(milestone_id,u["id"],u["id"])).fetchone()
    if not m:
        c.close(); flash("Milestone not found.","error"); return redirect(url_for("dashboard"))
    status=request.form.get("status","Pending")
    if status not in {"Pending","In Progress","Completed","Cancelled"}: status=m["status"]
    paid = c.execute("SELECT 1 FROM milestone_payments WHERE milestone_id=? AND status='Released'", (milestone_id,)).fetchone()
    if paid:
        c.close(); flash("A milestone with a released payment can no longer be changed.", "error"); return redirect(url_for("contract_detail",contract_id=m["contract_id"]))
    if status != "Completed":
        c.execute("UPDATE milestones SET status=?, professional_verified=0, client_verified=0, professional_verified_at=NULL, client_verified_at=NULL, updated_at=CURRENT_TIMESTAMP WHERE id=?",(status,milestone_id))
    else:
        c.execute("UPDATE milestones SET status=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",(status,milestone_id))
    c.commit(); c.close()
    return redirect(url_for("contract_detail",contract_id=m["contract_id"]))

@app.route("/contracts/<int:contract_id>/deliverables/new", methods=["POST"])
def create_deliverable(contract_id):
    u = user()
    if not u:
        return redirect(url_for("login"))
    c = db()
    contract = c.execute("SELECT * FROM contracts WHERE id=? AND (client_id=? OR professional_id=?)",
                         (contract_id, u["id"], u["id"])).fetchone()
    if not contract:
        c.close(); flash("Contract not found.", "error"); return redirect(url_for("contracts"))
    if u["id"] != contract["professional_id"]:
        c.close(); flash("Only the professional can submit project deliverables.", "error"); return redirect(url_for("contract_detail", contract_id=contract_id))

    title = request.form.get("title", "").strip()
    if not title:
        c.close(); flash("Deliverable title is required.", "error")
        return redirect(url_for("contract_detail", contract_id=contract_id))

    milestone_id = request.form.get("milestone_id") or None
    task_id = request.form.get("task_id") or None

    if milestone_id:
        valid = c.execute("SELECT id FROM milestones WHERE id=? AND contract_id=?", (milestone_id, contract_id)).fetchone()
        if not valid: milestone_id = None
    if task_id:
        valid = c.execute("SELECT id FROM tasks WHERE id=? AND contract_id=?", (task_id, contract_id)).fetchone()
        if not valid: task_id = None

    c.execute("""INSERT INTO deliverables
        (contract_id,milestone_id,task_id,title,description,submission_url,submitted_by)
        VALUES(?,?,?,?,?,?,?)""", (
        contract_id, milestone_id, task_id, title,
        request.form.get("description", "").strip(),
        request.form.get("submission_url", "").strip(), u["id"]
    ))
    c.commit(); c.close()
    flash("Deliverable submitted for review.", "success")
    return redirect(url_for("contract_detail", contract_id=contract_id))

@app.route("/deliverables/<int:deliverable_id>/review", methods=["POST"])
def review_deliverable(deliverable_id):
    u = user()
    if not u:
        return redirect(url_for("login"))
    c = db()
    d = c.execute("""SELECT deliverables.*, contracts.client_id, contracts.professional_id
        FROM deliverables JOIN contracts ON contracts.id=deliverables.contract_id
        WHERE deliverables.id=? AND (contracts.client_id=? OR contracts.professional_id=?)""",
        (deliverable_id, u["id"], u["id"])).fetchone()
    if not d:
        c.close(); flash("Deliverable not found.", "error"); return redirect(url_for("dashboard"))

    # Only the client can approve or request revisions. The professional owns submission.
    if u["id"] != d["client_id"]:
        c.close(); flash("Only the client can review a deliverable.", "error")
        return redirect(url_for("contract_detail", contract_id=d["contract_id"]))

    status = request.form.get("status", "")
    if status not in {"Approved", "Revision Requested"}:
        c.close(); flash("Invalid review status.", "error")
        return redirect(url_for("contract_detail", contract_id=d["contract_id"]))

    note = request.form.get("review_note", "").strip()
    c.execute("""UPDATE deliverables
        SET status=?, review_note=?, reviewed_at=CURRENT_TIMESTAMP
        WHERE id=?""", (status, note, deliverable_id))
    c.commit(); c.close()
    flash("Deliverable review saved.", "success")
    return redirect(url_for("contract_detail", contract_id=d["contract_id"]))

@app.route("/contracts/<int:contract_id>/disputes/new", methods=["POST"])
def create_dispute(contract_id):
    u = user()
    if not u:
        return redirect(url_for("login"))
    c = db()
    contract = c.execute("SELECT * FROM contracts WHERE id=? AND (client_id=? OR professional_id=?)", (contract_id, u["id"], u["id"])).fetchone()
    if not contract:
        c.close(); flash("Contract not found.", "error"); return redirect(url_for("contracts"))
    reason = request.form.get("reason", "").strip()
    description = request.form.get("description", "").strip()
    if not reason or not description:
        c.close(); flash("A reason and description are required to open a dispute.", "error"); return redirect(url_for("contract_detail", contract_id=contract_id))
    milestone_id = request.form.get("milestone_id") or None
    if milestone_id:
        valid = c.execute("SELECT id FROM milestones WHERE id=? AND contract_id=?", (milestone_id, contract_id)).fetchone()
        if not valid:
            milestone_id = None
    against = contract["professional_id"] if u["id"] == contract["client_id"] else contract["client_id"]
    c.execute("""INSERT INTO disputes(contract_id,milestone_id,opened_by,against_user_id,reason,description,evidence_url)
                 VALUES(?,?,?,?,?,?,?)""", (contract_id, milestone_id, u["id"], against, reason, description, request.form.get("evidence_url", "").strip()))
    c.commit(); c.close()
    flash("Dispute opened. The affected milestone payment is paused until the dispute is resolved.", "success")
    return redirect(url_for("contract_detail", contract_id=contract_id))

@app.route("/disputes/<int:dispute_id>/status", methods=["POST"])
def update_dispute_status(dispute_id):
    u = user()
    if not u:
        return redirect(url_for("login"))
    c = db()
    d = c.execute("""SELECT disputes.*, contracts.client_id, contracts.professional_id
        FROM disputes JOIN contracts ON contracts.id=disputes.contract_id
        WHERE disputes.id=? AND (contracts.client_id=? OR contracts.professional_id=?)""", (dispute_id, u["id"], u["id"])).fetchone()
    if not d:
        c.close(); flash("Dispute not found.", "error"); return redirect(url_for("dashboard"))
    status = request.form.get("status", "")
    if status not in {"Under Review", "Resolved", "Rejected", "Closed"}:
        c.close(); flash("Invalid dispute status.", "error"); return redirect(url_for("contract_detail", contract_id=d["contract_id"]))
    resolution = request.form.get("resolution", "").strip()
    if status in {"Resolved", "Rejected"} and not resolution:
        c.close(); flash("Add a resolution note before closing the dispute.", "error"); return redirect(url_for("contract_detail", contract_id=d["contract_id"]))
    if status == "Closed" and d["status"] not in {"Resolved", "Rejected"}:
        c.close(); flash("A dispute must first be resolved or rejected.", "error"); return redirect(url_for("contract_detail", contract_id=d["contract_id"]))
    if status in {"Resolved", "Rejected", "Closed"}:
        c.execute("UPDATE disputes SET status=?, resolution=?, resolved_by=?, resolved_at=CURRENT_TIMESTAMP WHERE id=?", (status, resolution, u["id"], dispute_id))
    else:
        c.execute("UPDATE disputes SET status=? WHERE id=?", (status, dispute_id))
    c.commit(); c.close()
    flash("Dispute status updated.", "success")
    return redirect(url_for("contract_detail", contract_id=d["contract_id"]))

@app.route("/messages/<int:other_id>", methods=["GET","POST"])
def messages(other_id):
    u=user()
    if not u: return redirect(url_for("login"))
    c=db(); other=c.execute("SELECT * FROM users WHERE id=?",(other_id,)).fetchone()
    if request.method=="POST" and request.form.get("body","").strip():
        c.execute("INSERT INTO messages(sender_id,receiver_id,body) VALUES(?,?,?)",(u["id"],other_id,request.form["body"].strip())); c.commit()
    msgs=c.execute("""SELECT messages.*,users.name sender_name FROM messages JOIN users ON users.id=messages.sender_id
                      WHERE (sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?) ORDER BY messages.id""",
                   (u["id"],other_id,other_id,u["id"])).fetchall()
    c.close(); return render_template("messages.html",other=other,messages=msgs)

@app.route("/api/messages/<int:other_id>")
def api_messages(other_id):
    u=user()
    if not u: return jsonify(error="login required"),401
    c=db(); rows=c.execute("""SELECT messages.id,messages.body,messages.created_at,users.name sender_name
                              FROM messages JOIN users ON users.id=messages.sender_id
                              WHERE (sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?) ORDER BY messages.id""",
                           (u["id"],other_id,other_id,u["id"])).fetchall(); c.close()
    return jsonify(messages=[dict(x) for x in rows])

if __name__=="__main__":
    init_db(); app.run(debug=True)
