# TechConnect final workflow test

Use two accounts: one `Client`/`hire professional` account and one `Professional` account.

1. Register both accounts and confirm login/session persistence.
2. Client posts a project.
3. Professional opens Find Work and submits a proposal.
4. Client accepts the proposal; confirm a contract is created as **Awaiting Agreement**.
5. Both parties accept the agreement; confirm the contract becomes **Active**.
6. Confirm the workspace is available only after both agreements are accepted.
7. Client/professional create milestones and tasks.
8. Professional submits a deliverable; client approves it or requests a revision.
9. Mark a milestone **Completed**.
10. Both parties verify milestone completion.
11. Confirm only the hiring client can release the milestone payment.
12. Open a dispute and confirm affected payment/final completion is blocked while it is open.
13. Resolve/close the dispute.
14. Release all milestone payments.
15. Confirm the final contract cannot close while milestones, payments, deliverable reviews, or disputes remain incomplete.
16. Client closes the Active contract as **Completed**.
17. Confirm the 10% TechConnect fee is recorded only at final settlement and the settlement shows the professional net amount.

The project includes server-side validation for the above workflow; the supplied environment used for packaging did not have Flask installed and could not reach the package repository, so a live Flask browser smoke test could not be executed here.
