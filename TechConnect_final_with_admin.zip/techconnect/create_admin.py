#!/usr/bin/env python3
"""Create a TechConnect administrator account.

Usage:
    python3 create_admin.py admin@example.com

The password is prompted securely and is never stored in this script.
Public registration never permits the admin role.
"""
import getpass, hashlib, os, sqlite3, sys

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, "vibelink.db")

if len(sys.argv) != 2:
    print("Usage: python3 create_admin.py admin@example.com")
    raise SystemExit(1)

email = sys.argv[1].strip().lower()
name = input("Administrator name: ").strip()
password = getpass.getpass("Administrator password (min 6 chars): ")
confirm = getpass.getpass("Confirm password: ")

if not name or len(password) < 6 or password != confirm:
    print("Invalid name/password or passwords do not match.")
    raise SystemExit(1)

conn = sqlite3.connect(DB)
try:
    conn.execute("ALTER TABLE users ADD COLUMN account_status TEXT DEFAULT 'Active'")
except sqlite3.OperationalError:
    pass

digest = hashlib.sha256(password.encode()).hexdigest()
row = conn.execute("SELECT id FROM users WHERE email=?", (email,)).fetchone()
if row:
    conn.execute("""UPDATE users SET name=?, password=?, account_type='admin',
                    account_status='Active' WHERE id=?""",
                 (name, digest, row[0]))
else:
    conn.execute("""INSERT INTO users(name,email,password,account_type,account_status)
                    VALUES(?,?,?,?,?)""",
                 (name,email,digest,"admin","Active"))
conn.commit()
conn.close()
print("Admin account ready.")
print("Open /admin/login to sign in.")
